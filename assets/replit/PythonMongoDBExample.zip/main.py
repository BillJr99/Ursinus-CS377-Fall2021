# https://www.mongodb.com/blog/post/getting-started-with-python-and-mongodb
# pip install pymongo pymongo[srv]
# DBUSER=... DBPASSWORD=... DBNAME=... python main.py in Control-Shift-S terminal mode

from pymongo import MongoClient
import os

# control-shift-S to launch repl.it shell and set these variables
user = os.environ.get('DBUSER');
password = os.environ.get('DBPASSWORD');
dbname = os.environ.get('DBNAME');

# Set database user, IP network access, and get connection string from mongodb.com (remember to shut down when done)
url = "mongodb+srv://" + user + ":" + password + "@cluster0.t74xp.mongodb.net/" + dbname + "?retryWrites=true&w=majority";

client = MongoClient(url)

db = client.library

entry = {"title": "Database Design", "edition": 2, "authors": ["Adrienne Watt", "Nelson Eng"]}

db.books.insert_one(entry)

query = db.books.find_one({'title': "Database Design"})

print(query)