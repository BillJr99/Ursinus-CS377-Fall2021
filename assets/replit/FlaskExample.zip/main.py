from flask import Flask, abort, request
import json

# Control-Shift-S for shell
# curl http://127.0.0.1:5000/api/v1/person
# curl http://127.0.0.1:5000/api/v1/person -X POST -H "Content-Type: application/json" -d '{"name": "Bill", "age": 39}'
app = Flask("example")

people = []

def get_max_id():
  global people
  
  maxid = -1
  for i in range(len(people)):
    if people[i]['id'] > maxid:
      maxid = people[i]['id']
  return maxid

@app.route('/api/v1/person', methods=['GET'])
def get_people():
  global people

  return json.dumps(people)

@app.route('/api/v1/person/<int:personId>', methods=['GET'])
def get_person(personId):
  global people

  person = None
  for i in range(len(people)):
    if people[i]['id'] == personId:
      person = people[i]
      break

  if not (person is None):    
    return json.dumps()
  else:
    abort(404) # not found

@app.route('/api/v1/person', methods=['POST'])
def create_person():
  global people

  id = get_max_id() + 1
  body = request.json

  person = {}
  person['id'] = id
  person['name'] = body.get("name", "")
  person['age'] = body.get("age", -1)

  people.append(person)

  return json.dumps(person), 201 # created

if __name__ == "__main__":
    app.run(debug=True)