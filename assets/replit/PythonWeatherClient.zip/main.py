# https://urllib3.readthedocs.io/en/latest/user-guide.html

import urllib3
import json

# Creating a PoolManager instance for sending requests.
http = urllib3.PoolManager()

# Sending a GET request and getting back response as HTTPResponse object.
resp = http.request("GET", "https://api.weatherusa.net/v1/obs?station_id=KLOM")

# Print the returned data.
print(resp.data)

respjson = json.loads(resp.data)

print(respjson)

print(("Weather at {}\nSky: {}\nTemperature: {}").format(respjson[0]['station_id'], respjson[0]['sky'], respjson[0]['t_f']))