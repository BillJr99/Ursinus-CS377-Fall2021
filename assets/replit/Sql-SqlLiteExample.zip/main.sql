.header on
.mode column

CREATE TABLE mytable (a int);
INSERT INTO mytable VALUES(42);
SELECT * FROM mytable;