.header on
.mode column

-- Students Table
CREATE TABLE STUDENTS (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
    FirstName TEXT NOT NULL, 
    LastName TEXT NOT NULL, 
    Age INTEGER
);

INSERT INTO STUDENTS (FirstName, LastName, Age) VALUES ("Alex", "Smith", 20);
INSERT INTO STUDENTS (FirstName, LastName, Age) VALUES ("Lee", "Jones", 21);
INSERT INTO STUDENTS (FirstName, LastName, Age) VALUES ("Brian", "McMullen", 18);
INSERT INTO STUDENTS (FirstName, LastName, Age) VALUES ("Samantha", "Johnson", 22);
INSERT INTO STUDENTS (FirstName, LastName, Age) VALUES ("Lee", "Jones", 24);

-- Courses Table
CREATE TABLE COURSES (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  CourseNum TEXT NOT NULL, 
  CourseName TEXT NOT NULL
);

INSERT INTO COURSES (CourseNum, CourseName) VALUES ("CS377", "Database Design");
INSERT INTO COURSES (CourseNum, CourseName) VALUES ("CS173", "Intro to Computer Science");
INSERT INTO COURSES (CourseNum, CourseName) VALUES ("CS174", "Object Oriented Programming");
INSERT INTO COURSES (CourseNum, CourseName) VALUES ("CS275", "Software Engineering");

-- Link the Tables Together with Primary and Foreign Keys
CREATE TABLE ENROLLMENTS (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  StudentID INTEGER NOT NULL, 
  CourseID INTEGER NOT NULL, 
  FOREIGN KEY(StudentID) REFERENCES STUDENTS(ID), 
  FOREIGN KEY(CourseID) REFERENCES COURSES(ID)
);

INSERT INTO ENROLLMENTS(StudentID, CourseID) VALUES (1, 1);
INSERT INTO ENROLLMENTS(StudentID, CourseID) VALUES (2, 1);
INSERT INTO ENROLLMENTS(StudentID, CourseID) VALUES (3, 2);

-- Group
SELECT COUNT(STUDENTS.ID) As NumStudents, AVG(STUDENTS.Age) AS AvgAge
FROM STUDENTS
INNER JOIN ENROLLMENTS ON STUDENTS.ID = ENROLLMENTS.StudentID
GROUP BY ENROLLMENTS.CourseID