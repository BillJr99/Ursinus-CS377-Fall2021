.header on
.mode column

CREATE TABLE EMPLOYEES (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
    FirstName TEXT NOT NULL, 
    LastName TEXT NOT NULL, 
    Age INTEGER NOT NULL,
    Smoker INTEGER DEFAULT 0 NOT NULL
);

CREATE TABLE DEPENDENTS (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  FirstName TEXT NOT NULL, 
  LastName TEXT NOT NULL, 
  EmployeeID INTEGER NOT NULL,
  Smoker INTEGER DEFAULT 0 NOT NULL,
  Age INTEGER NOT NULL,
  FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEES(ID)
);

CREATE TABLE INSURED (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  InsuranceType TEXT NOT NULL,
  CoverageAmount REAL,
  EmployeeID INTEGER NOT NULL,
  FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEES(ID)
);

CREATE TABLE DEPENDENTCOVERAGE (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  InsuredID INTEGER NOT NULL,
  DependentID INTEGER NOT NULL,
  FOREIGN KEY(InsuredID) REFERENCES INSURED(ID),
  FOREIGN KEY(DependentID) REFERENCES DEPENDENTS(ID)
);

-- Get the schema description of any sqlite database!  Try it out
SELECT * FROM sqlite_master;

-- Note that booleans are integers with values 0, 1 in sqlite
INSERT INTO EMPLOYEES (FirstName, LastName, Age, Smoker) VALUES ("Alex", "Smith", 21, 0);

-- Retrieve the last inserted ID into employees
INSERT INTO DEPENDENTS (FirstName, LastName, EmployeeID, Age) VALUES ("Lee", "Smith", last_insert_rowid(), 1);

-- Now, the last inserted ID is the insertion into DEPENDENTS, but we can look up the foreign key value to get the employee ID!
INSERT INTO INSURED (InsuranceType, CoverageAmount, EmployeeID) VALUES ("Medical", 100000.00, (SELECT EmployeeID FROM DEPENDENTS WHERE ID=last_insert_rowid()));

-- Programmatically, this should be a loop over all dependents (which can be selected to obtain their ID's)
-- What does last_insert_rowid() refer to here?  What is the corresponding ID from the lookup of last_insert_rowid(), and what are we doing with it?
INSERT INTO DEPENDENTCOVERAGE (InsuredID, DependentID) VALUES (last_insert_rowid(), (SELECT ID FROM Dependents WHERE EmployeeID=(SELECT EmployeeID FROM INSURED WHERE ID=last_insert_rowid())));

SELECT * FROM EMPLOYEES;
SELECT * FROM DEPENDENTS;
SELECT * FROM INSURED;
SELECT * FROM DEPENDENTCOVERAGE;

-- Export options
-- .dump: writes the database commands to a file
-- .schema: writes the database schema commands to a file
-- .save main.db: saves the db file itself
-- with the db, run:
--    pip install eralchemy
--    eralchemy -i sqlite:///main.db -o main.dot
--    dot -Teps main.dot -o main.eps