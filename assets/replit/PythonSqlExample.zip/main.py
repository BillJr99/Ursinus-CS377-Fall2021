import sqlite3

# stmt contains placeholder ?'s for params
# params is a tuple (val1, val2, ...)
def query(con, stmt, params=None):
  cur = con.cursor()
  if params is None:
    result = cur.execute(stmt)
  else:
    result = cur.execute(stmt, params)
  con.commit()
  return result

con = sqlite3.connect('main.db')

res = query(con, "DROP TABLE IF EXISTS PERSON;")
res = query(con, "DROP TABLE IF EXISTS EMAIL;")

res = query(con, "CREATE TABLE PERSON (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, FirstName TEXT NOT NULL, LastName TEXT NOT NULL);")

res = query(con, "CREATE TABLE EMAIL (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, PersonID INTEGER NOT NULL, EMAILADDRESS TEXT NOT NULL, FOREIGN KEY(PersonID) REFERENCES PERSON(ID));")

fname = input("Enter First Name: ")
lname = input("Enter Last Name: ")
res = query(con, "INSERT INTO PERSON (FirstName, LastName) VALUES (?, ?);", (fname, lname))

res = query(con, "SELECT * FROM PERSON")
print(res.fetchall())