.header on
.mode column

-- Students Table
CREATE TABLE EMPLOYEES (
    ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
    FirstName TEXT NOT NULL, 
    LastName TEXT NOT NULL
);

INSERT INTO EMPLOYEES (FirstName, LastName) VALUES ("Alex", "Smith");
INSERT INTO EMPLOYEES (FirstName, LastName) VALUES ("Lee", "Jones");
INSERT INTO EMPLOYEES (FirstName, LastName) VALUES ("Brian", "McMullen");
INSERT INTO EMPLOYEES (FirstName, LastName) VALUES ("Samantha", "Johnson");
INSERT INTO EMPLOYEES (FirstName, LastName) VALUES ("Lee", "Jones");

-- Link the Tables Together with Primary and Foreign Keys
CREATE TABLE SALES (
  ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  EmployeeID INTEGER NOT NULL,
  Amount REAL DEFAULT 0, 
  FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEES(ID)
);

INSERT INTO SALES(EmployeeID, Amount) VALUES(1, 1000);
INSERT INTO SALES(EmployeeID, Amount) VALUES(1, 2000);
INSERT INTO SALES(EmployeeID, Amount) VALUES(2, 100);
-- Group

SELECT * FROM EMPLOYEES;
SELECT * FROM SALES;

-- Add Subquery Column
-- How is this similar to a JOIN?
SELECT ID, FirstName, LastName, (
  SELECT SUM(Amount) FROM SALES WHERE SALES.EmployeeID = EMPLOYEES.ID
) SalesTotal 
FROM EMPLOYEES 
ORDER BY SalesTotal DESC;

-- Filter By Subquery
SELECT * FROM EMPLOYEES WHERE (
  SELECT SUM(Amount) As TotalSales FROM SALES WHERE SALES.EmployeeID = EMPLOYEES.ID
) >= 1500
ORDER BY EMPLOYEES.LastName ASC;

