# hello world!
from Pet import Pet

def main():
  print("hello world")
  cat = Pet("cat", "Jeremy", "Orange", "meow")
  dog = Pet("dog", "Bobert", "Periwinkle", "bark", _level=2)
  cat.speak()
  dog.speak()
  print(cat.name)
  #cat.pet_evolution()
  print(cat.get_dict())
  print(dog.get_dict())
  
if __name__ == "__main__":
  main()