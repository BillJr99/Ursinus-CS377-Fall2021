import unittest
from Pet import Pet

class TestPet(unittest.TestCase):

  def test_pet(self):
    oliver = Pet("cat", "Oliver", "orange", "feed me")
    self.assertEqual(oliver.name, "Oliver")
    self.assertEqual(oliver.species, "cat")
    self.assertEqual(oliver.color, "orange")

if __name__ == '__main__':
    unittest.main()

# Run with:
# python -m unittest thisfile.py

# Profile with:
# python -m cProfile thisfile.py
