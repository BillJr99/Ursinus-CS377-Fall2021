class Pet:
  """
  Construct a... pet?  A Pet object, that is!

  :param _species: The species of the pet
  :param _name: The pet
  :param _color: The color of the pet
  :param _says: What does the pet say?
  """
  def __init__(self,_species,_name,_color,_says,_level=1):
    self.species = _species
    self.name = _name
    self.color = _color
    self.says = _says
    self.level = _level

  def speak(self):
    print(self.says)
  
  def get_dict(self):
    result = dict()
    result['name'] = self.name
    result['color'] = self.color

    return result

  def pet_evolution(self):
    self.level += 10
    newName = input("Give your pet a new name: ")
    self.name = newName
    newSpecies = input("Give your pet a new species: ")
    self.species = newSpecies
    newColor = input("Give your pet a new color: ")
    self.color = newColor