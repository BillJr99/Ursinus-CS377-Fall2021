import FileWriter

def main():
  fw = FileWriter.FileWriter("example.csv")

  bill = {"name": "Bill", "age": 38}
  alex = {"name": "Alex", "age": 20}

  fw.write_record(bill)
  fw.write_record(alex)
  try:
    fw.write_record("This is a test") # this should fail
  except TypeError:
    print("Could not write a string; continuing...")

if __name__ == "__main__":
  main()