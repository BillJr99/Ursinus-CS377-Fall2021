import FileWriter

def main():
  fr = FileWriter.FileWriter("example.csv")

  bill = {"name": "Bill", "age": 38}
  alex = {"name": "Alex", "age": 20}

  fr.write_record(bill)
  fr.write_record(alex)
  try:
    fr.write_record("This is a test") # this should fail
  except TypeError:
    print("Could not write a string; continuing...")

if __name__ == "__main__":
  main()